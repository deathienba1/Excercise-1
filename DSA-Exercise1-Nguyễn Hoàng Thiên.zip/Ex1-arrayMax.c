#include <stdio.h>
#define MAX 100

void Nhapmang(int a[], int *n)
{
    do{
        printf("Nhap so phan tu cua mang (n > 0): ");
        scanf("%d", n);
        if(*n <= 0)
        {
            printf("So luong phan tu phai lon hon 0, vui long nhap lai!\n");
        }
    }while (*n <= 0);
    
    for(int i = 0; i < *n; i++)
    {
        printf("Nhap a[%d]: ", i);
        scanf("%d", &a[i]);
    }
}

void Xuatmang(int a[], int n)
{
    for(int i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
}

int Max(int a[], int n)
{
    int max = a[0];
    for(int i = 1; i < n; i++)
    {
        if(a[i] > max)
        {
            max = a[i];
        }
    }
    return max;
}

int main()
{
    int A[MAX];
    int n;
    Nhapmang(A, &n);
    Xuatmang(A, n);
    int max = Max(A, n);
    printf("\nGia tri lon nhat trong mang la: %d\n", max);
    return 0;
}