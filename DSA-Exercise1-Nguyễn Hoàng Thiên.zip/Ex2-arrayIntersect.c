#include <stdio.h>
#define MAX 100

typedef struct
{
    int item[MAX];
    int size;
    int capacity;
} Array;

int isDuplicate(int x, int arr[], int size)
{
    for(int i = 0; i < size; i++)
    {
        if(arr[i] == x)
        {
            return 1;
        }
    }
    return 0;
}

Array arrayIntersect(Array a1, Array a2)
{
    Array result;
    result.size = 0;
    result.capacity = (a1.size < a2.size) ? a1.size : a2.size;

    for(int i = 0; i < a1.size; i++)
    {
        int x = a1.item[i];
        for(int j = 0; j < a2.size; j++)
        {
            if(!isDuplicate(x, result.item, result.size) && x == a2.item[j])
            {
                result.item[result.size++] = x;
            }
        }
    }
    return result;
}

void Nhapmang(Array *a)
{
    do{
        printf("Nhap so phan tu cua mang (n > 0): ");
        scanf("%d", &a->size);
        if(a->size <= 0)
        {
            printf("So luong phan tu phai lon hon 0, vui long nhap lai!\n");
        }
    }while (a->size <= 0);
    
    for(int i = 0; i < a->size; i++)
    {
        printf("Nhap a[%d]: ", i);
        scanf("%d", &a->item[i]);
    }
}

void Xuatmang(Array *a)
{
    for(int i = 0; i < a->size; i++)
    {
        printf("%d ", a->item[i]);
    }
}

int main()
{
    Array A1, A2;
    printf("Nhap mang 1:\n");
    Nhapmang(&A1);
    printf("Nhap mang 2:\n");
    Nhapmang(&A2);
    Xuatmang(&A1);
    printf("\n");
    Xuatmang(&A2);
    Array result = arrayIntersect(A1, A2);
    if(result.size == 0)
    {
        printf("Khong co phan tu trung nhau\n");
    }
    else
    {
        printf("\nCac phan tu trung nhau la: ");
        Xuatmang(&result);
    }
    return 0;
}
