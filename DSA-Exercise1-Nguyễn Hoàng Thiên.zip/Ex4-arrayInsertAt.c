#include <stdio.h>
#define MAX 100

typedef struct
{
    int item[MAX];
    int size;
    int capacity;
} Array;

void Nhapmang(Array *a)
{
    do{
        printf("Nhap so phan tu cua mang (n > 0): ");
        scanf("%d", &a->size);
        if(a->size <= 0)
        {
            printf("So luong phan tu phai lon hon 0, vui long nhap lai!\n");
        }
    }while (a->size <= 0);
    
    for(int i = 0; i < a->size; i++)
    {
        printf("Nhap a[%d]: ", i);
        scanf("%d", &a->item[i]);
    }
}

void Xuatmang(Array *a)
{
    for(int i = 0; i < a->size; i++)
    {
        printf("%d ", a->item[i]);
    }
}

void arrayInsertAt(Array *a, int input, int index)
{
    //Kiểm tra vị trí nhập
    if(index < 0 || index > a->size)
    {
        printf("Error: Invalid Index!\n");
        return;
    }
    //Kiểm tra mảng còn mở rộng được hay không
    if(a->size > a->capacity)
    {
        printf("Error: Array is full, cannot insert!\n");
        return;
    }
    //Dịch chuyển các phần tử sang phải 1 vị trí
    for(int i = a->size - 1; i >= index; i--)
    {
        a->item[i+1] = a->item[i];
    }
    //Chèn giá trị vào index và mở rộng mảng
    a->item[index] = input;
    a->size++;
}

int main()
{
    Array A;
    Nhapmang(&A);
    Xuatmang(&A);
    int value, index;
    printf("\nNhap gia tri can chen: ");
    scanf("%d", &value);
    printf("Nhap vi tri can chen: ");
    scanf("%d", &index);
    arrayInsertAt(&A, value, index);
    printf("Mang sau khi chen la:\n");
    Xuatmang(&A);
    return 0;
}