#include <stdio.h>
#define MAX 100

typedef struct
{
    int item[MAX];
    int size;
    int capacity;
} Array;

void Nhapmang(Array *a)
{
    do{
        printf("Nhap so phan tu cua mang (n > 0): ");
        scanf("%d", &a->size);
        if(a->size <= 0)
        {
            printf("So luong phan tu phai lon hon 0, vui long nhap lai!\n");
        }
    }while (a->size <= 0);
    
    for(int i = 0; i < a->size; i++)
    {
        printf("Nhap a[%d]: ", i);
        scanf("%d", &a->item[i]);
    }
}

void Xuatmang(Array *a)
{
    for(int i = 0; i < a->size; i++)
    {
        printf("%d ", a->item[i]);
    }
}

void arrayReverse(Array *a)
{
    int left = 0;
    int right = a->size - 1;
    while(left < right)
    {
        int temp = a->item[left];
        a->item[left] = a->item[right];
        a->item[right] = temp;
        left++;
        right--;
    }
}

int main()
{
    Array A;
    Nhapmang(&A);
    Xuatmang(&A);
    arrayReverse(&A);
    printf("\nMang sau khi dao nguoc la:\n");
    Xuatmang(&A);
    return 0;
}

